import { ViewFilesCodeEditor } from "@/components/viewfilescode-editor"

export default function Home() {
  return <ViewFilesCodeEditor />
}
